function [tempSeps, feCounter] = excludeSepVariables(funID, trialTimes)
    
    global benchmarkFunctions sfl sfu gamma;
    global epsilonList1 epsilonList2;    
    
    
    tempSeps = [];
    feCounter = 0;     
    sll = sfl;        
    suu = sfu;   
    dim = length(sfl.vector);    
    epsilon1 = epsilonList1(end);
    epsilon2 = epsilonList2(end);
       
    i = 1;
    tempVector = randperm(dim);
    
    while (i <= trialTimes)
        tempVar = tempVector(i);
        
        sul = sfl;        
        sul.vector(tempVar) = sfu.vector(tempVar);         
        sul.value = benchmarkFunctions(sul.vector, funID);
        
        slu = sfu;        
        slu.vector(tempVar) = sfl.vector(tempVar);
        slu.value = benchmarkFunctions(slu.vector, funID);
        
        feCounter = feCounter + 2;
        
        eEstimation = gamma * (abs(sll.value) + abs(sul.value) + abs(slu.value) + abs(suu.value));               
        indNumerator = abs(sll.value - sul.value - slu.value + suu.value) - eEstimation;                          
        indDenominator1 = 2 * max(abs(sll.value - sul.value), abs(slu.value - suu.value));
        %indDenominator2 = 2 * max(abs(sll.value - slu.value), abs(sul.value - suu.value));
        %indicator = max([indNumerator/indDenominator1, indNumerator/indDenominator2, eps]);
        indicator = max(indNumerator/indDenominator1, eps);
        
        if indicator * indicator < epsilon1 * epsilon2            
            tempSeps = [tempSeps, tempVar];
            trialTimes = dim;
            epsilon1 = max(indicator, epsilon1);
            epsilonList1 = [epsilonList1, epsilon1];
        else            
            epsilon2 = min(indicator, epsilon2);
            epsilonList2 = [epsilonList2, epsilon2];
        end
        
        i = i + 1;
    end

end