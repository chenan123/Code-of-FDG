% Ideally decompose benchmark functions in CEC 2010 according to their generation methods
% Author: Zhigang Ren
% email address: renzg@mail.xjtu.edu.cn


clear all;
clc;

nonseps = {};                   % each element of nonsepGroups is a vector which stores a group of nonseparable variables
seps = [];                      % store separable variables
overlapNum = 0;                 % the number of overlapping variables between two adjacent nonsepGroups. There is no overlapping nonseparable variables in CEC 2010 benchmark functions.
                                % Here overlapNum is used to provide a same interface with other benchmark functions
FEs = 0;                        % fitness evaluation times consumed. 
                                % IdealGroup needs no FE. Here FEs is used to provide a same interface with other grouping methods which need FEs 
dim = 1000;                     % CEC2010 benchmark functions only support dimension of 1000



nonseps = {};                   % fullly separable functions
seps = 1:dim;

for problemIndex = 1:3          
    fileName = sprintf('./CEC2010/F%02d', problemIndex);
    save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
end



for problemIndex = 4:8          % functions with a single group of m nonseparable variables
    m = 50;
    
    if ismember(problemIndex, [4:6])
        fileName = sprintf('./datafiles/f%02d_opm.mat', problemIndex);
    else
        fileName = sprintf('./datafiles/f%02d_op.mat', problemIndex);
    end    
    load(fileName, 'p');        % load p which is used to shuffle variables when generating the function
    if (1 ~= exist('p','var')) || (dim ~= length(p))
        error(['Cannot perform decomposition operation for function', num2str(problemIndex), '!']);
    end
    
    nonseps = {};               % perform clear operation
    nonseps{1} = p(1:m);
    seps = p((m + 1): end);
    
    fileName = sprintf('./CEC2010/F%02d', problemIndex);
    save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
end



for problemIndex = 9:13         % functions with dim/2m groups of m nonseparable variables
    m = 50;
    
    if ismember(problemIndex, [9:11])
        fileName = sprintf('./datafiles/f%02d_opm.mat', problemIndex);
    else
        fileName = sprintf('./datafiles/f%02d_op.mat', problemIndex);
    end  
    load(fileName, 'p');        % load p which is used to shuffle variables when generating the function
    if 1~= exist('p','var') || (dim ~= length(p))
        error(['Cannot perform decomposition operation for function', num2str(problemIndex), '!']);
    end
    
    nonseps = {};               % perform clear operation
    groupNum = dim / (2 * m);
    for g = 1: groupNum
        nonseps{g} = p(((g-1)*m+1): g*m);
    end
    seps = p((g*m + 1): end);
    
    fileName = sprintf('./CEC2010/F%02d', problemIndex);
    save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
end



for problemIndex = 14:18        % functions with dim/m groups of m nonseparable variables
    m = 50;
    
    if ismember(problemIndex, [14:16])
        fileName = sprintf('./datafiles/f%02d_opm.mat', problemIndex);
    else
        fileName = sprintf('./datafiles/f%02d_op.mat', problemIndex);
    end  
    load(fileName, 'p');        % load p which is used to shuffle variables when generating the function
    if 1~= exist('p','var') || (dim ~= length(p))
        error(['Cannot perform decomposition operation for function', num2str(problemIndex), '!']);
    end
    
    nonseps = {};               % perform clear operation
    groupNum = dim / m;
    for g = 1: groupNum
        nonseps{g} = p(((g-1)*m+1): g*m);
    end
    seps = [];       
    
    fileName = sprintf('./CEC2010/F%02d', problemIndex);
    save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
end



nonseps = {};                   % fullly nonseparable functions
nonseps{1} = 1:dim;
seps = [];

for problemIndex = 19:20          
    fileName = sprintf('./CEC2010/F%02d', problemIndex);
    save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
end
