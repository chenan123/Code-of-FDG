function [lBound, uBound] = GetBound2013(funID, dim)
% get the lower and upper bounds of each variable

    if ismember(funID, [1,4,7,8,11:15])
        lBound = -100 * ones(dim, 1);           %             lower bound of each dimension                  
        uBound = 100 * ones(dim, 1);            %             upper bound of each dimension                  
    elseif ismember(funID, [2,5,9])
        lBound = -5 * ones(dim, 1);             
        uBound = 5 * ones(dim, 1);              
    elseif ismember(funID, [3,6,10])
        lBound = -32 * ones(dim, 1);            
        uBound = 32 * ones(dim, 1);             
    else
        error(['There is no function', num2str(funID), '!']);
    end    
end

