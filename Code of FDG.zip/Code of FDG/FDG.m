% This source file is the entry point for FDG 
% Paper: An Fast Differential Grouping Algorithm for Large Scale Black-Box Optimization
% Submitted to IEEE Trans. Cybe
% Written by Zhigang Ren (email address: renzg@mail.xjtu.edu.cn)

close all;
clear all; 
clc;

global benchmarkSuite;                      % 'CEC2010' or 'CEC2013'                      
global benchmarkFunctions;                  % point to the benchmark functions implemented by the corresponding benchmark suite
global initial_flag;                        % a flag defined by the benchmark suite. For each benchmark function, it must be initialized to zero, which instructs the corresponding function to load or generate parameters

global gamma;                               
global sfl sfu;                             % struct: full l,u
global epsilonList1 epsilonList2;


                                        
%----------------------------------------------------------------------------------------------------
% Please specify benchmark suite, the name of benchmark functions, funcion IDs, etc.
benchmarkSuite = 'CEC2010';                 % or 'CEC2013'
benchmarkFunctions = @benchmark_func2010;   % for CEC2010, @benchmark_func2010; and for CEC2013,@benchmark_func2013
functionIDs = [1:20];                       % within [1:20] for 'CEC2010' and [1:15] for 'CEC2013'
trialTimes = 10;          
%----------------------------------------------------------------------------------------------------

disp(['-------------- Decompose ',benchmarkSuite,' Benchmark Functions with FDG --------------']);

suiteDirectory = ['./',benchmarkSuite];         % the file directory of the selected benchmark suite
dataDirectory = [suiteDirectory, '/datafiles']; % the file directory of the source data of the selected benchmark suite       
addpath(suiteDirectory, dataDirectory);         % add directories

if all(benchmarkSuite == 'CEC2010')
    dimList = 1000 * ones(1,20);                % the dimensions of CEC2010 benchmark functions. There are 20 functions in total in this benchmark suite
    GetBound = @GetBound2010;                   % point to the corresponding GetBound function
elseif all(benchmarkSuite == 'CEC2013')
    dimList = 1000 * ones(1,15);                % the dimensions of CEC2013 benchmark functions. There are 15 functions in total in this benchmark suite      
    dimList([13,14]) = 905;                     % Functions 13 and 14 are of 905 dimensions as their subproblems have overlapping variables
    GetBound = @GetBound2013;
else
    error(['FDG does not support ', benchmarkSuite, 'benchmark suite now!']);
end


for funID = functionIDs                         % decompose the selected functions one by one
    dim = dimList(funID);                       % get the dimension
    [lBound, uBound] = GetBound(funID, dim);    % get the lower and upper bounds of each variable
    
    initial_flag = 0;                           % tell benchmarkFunctions(benchmark_fun) to load the parameters of the current function
    muM = eps / 2;
    factor = 2;                       %2; dim^0.5; dim^0.5 + 2;
    gamma = factor*muM / (1 - factor*muM);
    
    sfl.vector = lBound; 
    sfl.value = benchmarkFunctions(sfl.vector, funID);
    sfu.vector = uBound; 
    sfu.value = benchmarkFunctions(sfu.vector, funID);
    FEs = 2;
    
    epsilonList1 = [];          %small threshold
    epsilonList2 = [];          %big threshold
    
    nonseps = {};
    seps = [];
    
    s = RandStream('mt19937ar','Seed','shuffle');
    RandStream.setGlobalStream(s);              % initialize the seed of random number 
                  
    [funType, feCounter] = identifyFunType(funID, trialTimes);
    FEs = FEs + feCounter;
    
    switch funType
    case 'ps'       
        [tempSeps, feCounter] = excludeSepVariables(funID, trialTimes);
        seps = [seps, tempSeps];
        FEs = FEs + feCounter;
        
        remainVars = setdiff([1:dim], seps); 
        subVector1 = remainVars(1);                         
        while (length(remainVars) > 1)                      %If there is only one variable left, the loop is not entered and the variable is treated directly as a separable variable.            
            subVector2 = setdiff(remainVars, subVector1);   
            if isempty(subVector2)                          %The detection variable is empty, and length (remainVars)>1, described as nonseparable variable
                nonseps = {nonseps{1:end},remainVars};
                remainVars = [];
                break;
            end
            
            [subVector1_r, feCounter] = bTreeDecomposition2(funID, subVector1, subVector2);
            FEs = FEs + feCounter;
            
            if length(subVector1_r) == length(subVector1)   %No new interacted variables are found
                if length(subVector1) == 1
                    seps = [seps, subVector1];
                else
                    nonseps = {nonseps{1:end},subVector1};
                end
                remainVars = subVector2;                     %'remainVars' is inevitably not empty
                subVector1 = remainVars(1);                     
            else
                subVector1 = subVector1_r;
            end                
                                                            
        end        
        seps = [seps, remainVars];
                      
    case 'ns'
        nonseps = {[1:dim]};
    case 'fs'
        seps = [1:dim];
    otherwise
        error(['The function type is wrong!']);
    end
    
    fileName = sprintf(['./FDGResults/',benchmarkSuite,'/F%02d'], funID);
    save(fileName, 'seps', 'nonseps', 'FEs','-v7');
        
    groupNum = length(nonseps);
    fprintf('%s%02d %s %s\n', 'Function', funID, 'type:', funType);
    fprintf('%s %03d\n', 'No. of separable variables:', length(seps));
    fprintf('%s %03d\n', 'No. of nonseparable variable groups:', groupNum);
    
    if groupNum > 0
        fprintf('%s ', 'No. of variables in each group:');
        for i = 1: length(nonseps)
            fprintf('%03d   ', length(nonseps{i}));
        end
        fprintf('\n');
    end
    
    fprintf('%s %05d\n\n', 'No. of FEs: ', FEs);
end



