function [subVector1_r, feCounter] = bTreeDecomposition2(funID, subVector1, subVector2)
    
    global benchmarkFunctions sfl sfu gamma;
    global epsilonList1 epsilonList2;    
             
    subVector1_r = subVector1;
    feCounter = 0;
    epsilon1 = epsilonList1(end);
    epsilon2 = epsilonList2(end);
    
    treeNodes = {};    
    curNode.vector = subVector2;    
    curNode.sll = sfl;
    
    curNode.sul = sfl;    
    curNode.sul.vector(subVector1) = sfu.vector(subVector1); 
    curNode.sul.value = benchmarkFunctions(curNode.sul.vector, funID);
    
%     curNode.slu = sfl;    
%     curNode.slu.vector(subVector2) = sfu.vector(subVector2);
%     curNode.slu.value = benchmarkFunctions(curNode.slu.vector, funID);
%     
%     curNode.suu = sfl;
%     curNode.suu.vector([subVector1, subVector2]) = sfu.vector([subVector1, subVector2]); 
%     curNode.suu.value = benchmarkFunctions(curNode.suu.vector, funID);
%     
%     feCounter = feCounter + 3;
    
    curNode.slu = sfu;
    curNode.slu.vector(subVector1) = sfl.vector(subVector1); 
    curNode.slu.value = benchmarkFunctions(curNode.slu.vector, funID);    
    curNode.suu = sfu;
    feCounter = feCounter + 2;

    treeNodes = {treeNodes{1:end}, curNode};
    
    while(~isempty(treeNodes))
        curNode = treeNodes{1};
        treeNodes(1) = [];
        
        eEstimation = gamma * (abs(curNode.sll.value) + abs(curNode.sul.value) + abs(curNode.slu.value) + abs(curNode.suu.value));        
        indNumerator = abs(curNode.sll.value - curNode.sul.value - curNode.slu.value + curNode.suu.value) - eEstimation;                                
        indDenominator1 = 2 * max(abs(curNode.sll.value - curNode.sul.value), abs(curNode.slu.value - curNode.suu.value));
        %indDenominator2 = 2 * max(abs(curNode.sll.value - curNode.slu.value), abs(curNode.sul.value - curNode.suu.value));
        %indicator = max([indNumerator/indDenominator1, indNumerator/indDenominator2, eps]);
        indicator = max(indNumerator/indDenominator1, eps);
        
        if indicator * indicator < epsilon1 * epsilon2            
            epsilon1 = max(indicator, epsilon1);
            epsilonList1 = [epsilonList1, epsilon1];
        else            
            epsilon2 = min(indicator, epsilon2);
            epsilonList2 = [epsilonList2, epsilon2];
            
            vectorLength = length(curNode.vector);
            if vectorLength < 2
                subVector1_r = [subVector1_r, curNode.vector];
            else
                size1 = floor(0.5 * vectorLength);
                leftNode = curNode;
                rightNode = curNode;
                leftNode.vector = curNode.vector(1:size1);
                rightNode.vector = curNode.vector((size1+1):vectorLength);
                
                leftNode.slu.vector(rightNode.vector) = sfl.vector(rightNode.vector);
                leftNode.suu.vector(rightNode.vector) = sfl.vector(rightNode.vector);
                leftNode.slu.value = benchmarkFunctions(leftNode.slu.vector, funID);
                leftNode.suu.value = benchmarkFunctions(leftNode.suu.vector, funID);
                feCounter = feCounter + 2;
                
                rightNode.sll = leftNode.slu;
                rightNode.sul = leftNode.suu;
                
                treeNodes = {treeNodes{1:end}, leftNode, rightNode};                                            
            end                        
        end      
    end
end