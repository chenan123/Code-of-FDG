% Ideally decompose benchmark functions in CEC 2013 according to their generation methods
% Author: Zhigang Ren
% email address: renzg@mail.xjtu.edu.cn


clear all;
clc;

nonseps = {};       % each element of nonsepGroups is a vector which stores a group of nonseparable variables
seps = [];          % store separable variables
overlapNum = 0;     % the number of overlapping variables between two adjacent nonsepGroups. 
FEs = 0;            % fitness evaluation times consumed. 
                    % IdealGroup2013 needs no FE. Here FEs is used to provide a same interface with other grouping methods which need FEs 
dim = 1000;         % CEC2013 benchmark functions only support dimension of 1000



nonseps = {};       % fullly separable functions
seps = 1:dim;

for problemIndex = 1:3          
    fileName = sprintf('./CEC2013/F%02d', problemIndex);
    save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
end



for problemIndex = 4:7          % functions with length(s) groups of nonseparable variables
    fileName = sprintf('./datafiles/f%02d.mat', problemIndex);
    load(fileName, 'p', 's');   % load p and s which are used to shuffle variables and specify the size of each group, respectively.
    if (1 ~= exist('p','var')) || (1 ~= exist('s','var')) || (dim ~= length(p)) || (dim < sum(s))
        error(['Cannot perform decomposition operation for function', num2str(problemIndex), '!']);
    end
    
    nonseps = {};               % perform clear operation
    groupNum = length(s);       % the number of groups containing nonseparable variables
    startDim = 1;
    for g = 1: groupNum
        endDim = startDim + s(g) - 1;
        nonseps{g} = p(startDim: endDim);
        startDim = endDim + 1;
    end
    
    seps = p(startDim: end);    % the number of separable variables is specified by the last element of s 
        
    fileName = sprintf('./CEC2013/F%02d', problemIndex);
    save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
end



seps = [];                      % perform clear operation since there is no separable variable

for problemIndex = 8:11         % functions with length(s) groups of nonseparable variables
    fileName = sprintf('./datafiles/f%02d.mat', problemIndex);
    load(fileName, 'p', 's');   % load p and s which are used to shuffle variables and decide the sizes of groups, respectively.
    if (1 ~= exist('p','var')) || (1 ~= exist('s','var')) || (dim ~= length(p)) || (dim ~= sum(s))
        error(['Cannot perform decomposition operation for function', num2str(problemIndex), '!']);
    end
    
    nonseps = {};               % perform clear operation
    groupNum = length(s);       % the number of groups containing nonseparable variables
    startDim = 1;
    for g = 1: groupNum
        endDim = startDim + s(g) - 1;
        nonseps{g} = p(startDim: endDim);
        startDim = endDim + 1;
    end
        
    fileName = sprintf('./CEC2013/F%02d', problemIndex);
    save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
end



% problemIndex = 12;              % overlapping function with overlapNum = 1
% nonseps = {};                   % perform clear operation
% seps = [];                      % 
% overlapNum = 1;                 % the number of overlapping variables between two adjacent nonsepGroups. 
% 
% groupNum = dim - 1;
% for g = 1: groupNum
%     nonseps{g} = g: (g+1);
% end
% 
% fileName = sprintf('./CEC2013/F%02d', problemIndex);
% save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
% 
% 
% 
% for problemIndex = 13:14        % overlapping functions with overlapNum specified by m
%     fileName = sprintf('./datafiles/f%02d.mat', problemIndex);
%     load(fileName, 'p', 's', 'm');   % load relative parameters
%         
%     nonseps = {};% perform clear operation
%     overlapNum = m;   % the number of overlapping variables between two adjacent nonsepGroups. 
%     groupNum = length(s);       % the number of groups containing nonseparable variables
%     startDim = 1;
%     for g = 1: groupNum
%         endDim = startDim + s(g) - 1;
%         nonseps{g} = p(startDim: endDim);
%         startDim = endDim - m + 1;
%     end
%         
%     fileName = sprintf('./CEC2013/F%02d', problemIndex);
%     save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
% end
% 
% 
% 
% problemIndex = 15;              % fullly nonseparable functions
% nonseps = {};    % perform clear operation  
% nonseps{1} = 1:dim;
% seps = [];
% overlapNum = 0;
% fileName = sprintf('./CEC2013/F%02d', problemIndex);
% save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
% 


%--------------------------------------------------------------------------
%���������ڷֽ�ʱ�������Ƿ����غ�
nonseps = {};    % perform clear operation  
seps = [];
overlapNum = 0;
for problemIndex = 12:15
    if ismember(problemIndex, [13,14])
        dim = 905;
    else
        dim = 1000;
    end
    nonseps{1} = 1:dim;
    fileName = sprintf('./CEC2013/F%02d', problemIndex);
    save(fileName, 'nonseps', 'seps', 'FEs', '-v7');
end


