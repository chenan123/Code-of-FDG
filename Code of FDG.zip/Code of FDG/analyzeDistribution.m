function funType = analyzeDistribution(indicatorList)
    
    global epsilonList1 epsilonList2;    
    
    indicatorNum = length(indicatorList);
    [~, sortIndex] = sort(indicatorList, 'ascend'); 
    lambdaList = indicatorList(sortIndex(2:end)) ./ indicatorList(sortIndex(1:(indicatorNum-1)));
    [maxLambda, index1] = max(lambdaList);
    tempList = lambdaList;
    tempList(index1) = -inf;
    [sMaxLambda, index2] = max(tempList);
    
    t = 1:(indicatorNum-1);
    figure;
    semilogy(t,lambdaList,'bo', index1,maxLambda,'r*',index2,sMaxLambda,'r*');
    
    if 1000 * sMaxLambda < maxLambda
        funType = 'ps';
        epsilon1 = indicatorList(sortIndex(index1));
        epsilon2 = indicatorList(sortIndex(index1 + 1));
        epsilonList1 = [epsilonList1, epsilon1];
        epsilonList2 = [epsilonList2, epsilon2];
    else
        if all(indicatorList > eps)
            funType = 'ns';
        else
            funType = 'fs';
        end
    end
end