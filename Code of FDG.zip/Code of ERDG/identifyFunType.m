
function [funType, feCounter] = identifyFunType(funID, trialTimes)
    
    global benchmarkFunctions sfl sfu gamma;
    
    funType = '';
    feCounter = 0;     
    sll = sfl;     
    dim = length(sfl.vector);    
    indicatorList = zeros(1, 2*trialTimes);   
    size1 = floor(0.5*dim);
    
    for i = 1: 2*trialTimes
        tempVector = randperm(dim);
        
        if i <= trialTimes 
            subVector1 = tempVector(1: size1);
            subVector2 = tempVector((size1+1): dim);
            suu = sfu;
        else
            subVector1 = tempVector(1);
            subVector2 = tempVector(end);
            suu = sfl;            
            suu.vector([subVector1, subVector2]) = sfu.vector([subVector1, subVector2]);
            suu.value = benchmarkFunctions(suu.vector, funID);
            feCounter = feCounter + 1;
        end
        
        sul = sfl;        
        sul.vector(subVector1) = sfu.vector(subVector1);
        sul.value = benchmarkFunctions(sul.vector, funID);
        
        slu = sfl;      
        slu.vector(subVector2) = sfu.vector(subVector2);
        slu.value = benchmarkFunctions(slu.vector, funID);
        
        feCounter = feCounter + 2;
        
%         delta1 = sll.value - sul.value;
%         delta2 = sul.value - suu.value;
        
        eEstimation = gamma * (abs(sll.value) + abs(sul.value) + abs(slu.value) + abs(suu.value));             
        indNumerator = abs(sll.value - sul.value - slu.value + suu.value) - eEstimation;         
        indDenominator1 = 2 * max(abs(sll.value - sul.value), abs(slu.value - suu.value));
        %indDenominator2 = 2 * max(abs(sll.value - slu.value), abs(sul.value - suu.value));
        %indicator = max([indNumerator/indDenominator1, indNumerator/indDenominator2, eps]);
        indicator = max(indNumerator/indDenominator1, eps);
        
        indicatorList(i) = indicator;                 
    end
    
    funType = analyzeDistribution(indicatorList);
end